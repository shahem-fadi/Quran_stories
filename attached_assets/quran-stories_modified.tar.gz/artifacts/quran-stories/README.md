# قصص القرآن الكريم — Quran Stories

موقع تعليمي لاستكشاف قصص القرآن الكريم بطريقة منظمة ومفصّلة، مع الآيات والعبر المستفادة.

---

## Tech Stack

| Layer | Technology |
|---|---|
| Framework | React 19 + Vite |
| Language | TypeScript |
| Styling | Tailwind CSS v4 |
| Routing | Wouter |
| Fonts | Cairo (UI) + Amiri (Quranic text) |
| Data | Local static TypeScript files |

---

## Features

- 🕌 **Arabic RTL layout** — full right-to-left direction throughout
- 🎨 **Islamic-inspired design** — soft green, cream, and gold color palette
- 📖 **Stories listing page** — searchable, filterable by category
- 🌿 **Story detail pages** — summary, Quran verses, embedded video, lessons
- 🔍 **Search & filter** — find stories by name, prophet, or surah
- 📱 **Fully responsive** — mobile-friendly navbar and layouts
- 🏛️ **4 categories** — Prophets, Past Nations, Righteous People, Lessons & Wisdom
- ⭐ **8 stories** — with placeholder structure for unlimited expansion

---

## Project Structure

```
src/
├── data/
│   └── stories.ts         # All story data — single source of truth
├── pages/
│   ├── Home.tsx           # Homepage with hero, stats, featured stories
│   ├── Stories.tsx        # Stories listing with search & filter
│   ├── StoryDetail.tsx    # Individual story page
│   └── not-found.tsx      # 404 page
├── components/
│   ├── Navbar.tsx         # Sticky Arabic navigation bar
│   └── Footer.tsx         # Site footer with links
├── App.tsx                # Router setup
└── index.css              # Global styles & design tokens
```

---

## How to Run Locally

```bash
# Install dependencies
pnpm install

# Start the dev server
pnpm --filter @workspace/quran-stories run dev
```

Then open `http://localhost:[PORT]` in your browser.

---

## Adding a New Story

Open `src/data/stories.ts` and add a new object to the `stories` array:

```ts
{
  id: 9,
  slug: "story-slug",
  title: "عنوان القصة",
  shortSummary: "ملخص قصير...",
  fullSummary: "النص الكامل...",
  category: "أنبياء",   // أنبياء | أمم سابقة | صالحون | عبر ومواعظ
  prophetName: "اسم النبي",
  relatedSurahs: ["البقرة", "آل عمران"],
  verses: [
    {
      surah: "البقرة",
      ayah: 1,
      text: "نص الآية",
      explanation: "شرح مختصر",
    },
  ],
  videoUrl: "https://www.youtube.com/embed/VIDEO_ID",
  lessons: ["العبرة الأولى", "العبرة الثانية"],
  icon: "🌙",
  featured: false,
}
```

---

## Adding a Real YouTube Video

In `src/data/stories.ts`, replace `PLACEHOLDER_*` in `videoUrl` with the actual YouTube video ID:

```ts
videoUrl: "https://www.youtube.com/embed/dQw4w9WgXcQ"
```

---

## Future Improvements

- [ ] Connect to a real Quran API (e.g. `alquran.cloud`) for verified verse text
- [ ] Add audio recitation player for each verse
- [ ] Add Prophets index page (`/prophets`)
- [ ] Add Surahs browser page (`/surahs`)
- [ ] Add bookmarks / favorites with localStorage
- [ ] Add dark mode toggle
- [ ] Add pagination for large story lists
- [ ] Integrate a CMS (e.g. Sanity) for non-developer content editing
